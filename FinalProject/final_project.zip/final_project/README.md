# final_project
Complete package for the final project submission of Group22 for: ENPM809Y Fall 2021

- The `doc` folder contains the instructions.
- The `script` folder contains install.bash to install required packages.


## Personnel
Ninad Harishchandrakar (ninadh@umd.edu), Prasanna Raghavan (pthiruku@umd.edu), Sai Sandeep Adapa (sadapa@umd.edu)







