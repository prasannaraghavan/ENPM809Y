var annotated_dup =
[
    [ "XmlRpc", "namespace_xml_rpc.html", "namespace_xml_rpc" ]
];