var searchData=
[
  ['doublefromxml',['doubleFromXml',['../class_xml_rpc_1_1_xml_rpc_value.html#a96327cdb81552fda14dde4c83d7289c2',1,'XmlRpc::XmlRpcValue']]],
  ['doubletoxml',['doubleToXml',['../class_xml_rpc_1_1_xml_rpc_value.html#a197e144f4e7c0fbaf4ba0b129bb22537',1,'XmlRpc::XmlRpcValue']]]
];
