var indexSectionsWithContent =
{
  0: "acfmr",
  1: "mr",
  2: "cfm",
  3: "a",
  4: "m",
  5: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Pages"
};

