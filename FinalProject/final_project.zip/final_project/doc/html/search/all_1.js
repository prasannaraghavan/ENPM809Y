var searchData=
[
  ['changegoal',['changeGoal',['../main_8cpp.html#acb19a837752ce988cd69607431ad979d',1,'main.cpp']]]
];
