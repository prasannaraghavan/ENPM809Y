var searchData=
[
  ['getdoubleformat',['getDoubleFormat',['../class_xml_rpc_1_1_xml_rpc_value.html#a70ec0df6e27b1975e40b81b7b761e665',1,'XmlRpc::XmlRpcValue']]],
  ['gettype',['getType',['../class_xml_rpc_1_1_xml_rpc_value.html#a3faf411016f2d2d437fe26c8eadc265e',1,'XmlRpc::XmlRpcValue']]]
];
