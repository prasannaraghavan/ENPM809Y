var searchData=
[
  ['aruco_5fid',['aruco_id',['../main_8cpp.html#a4b63724ec5fcfb099696d3dec0fa6746',1,'main.cpp']]],
  ['aruco_5fmarker_5ffound',['aruco_marker_found',['../main_8cpp.html#a2db5684d4670f161c628d7800c07ff03',1,'main.cpp']]]
];
