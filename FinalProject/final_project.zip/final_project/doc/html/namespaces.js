var namespaces =
[
    [ "XmlRpc", "namespace_xml_rpc.html", null ]
];